/* Harf typing test: Urdu / Pashto speed + accuracy, phonetic keys optional. Config in window.HARF_T */
(function () {
  var C = window.HARF_T; if (!C) return;
  var box = document.getElementById('tt-text'), inp = document.getElementById('tt-in'), lvl = document.getElementById('tt-level'), dur = document.getElementById('tt-dur');
  var S = { w: document.getElementById('tt-wpm'), a: document.getElementById('tt-acc'), t: document.getElementById('tt-time'), e: document.getElementById('tt-err') };
  var res = document.getElementById('tt-res'), phon = document.getElementById('tt-phon');
  var text = '', start = 0, timer = null, done = false, limit = 60, usePhon = true;
  var PUN = { ',': '،', '.': '۔', '?': '؟', ';': '؛' };
  function pick() {
    var pool = C.passages[lvl.value] || C.passages.medium, i = Math.floor(Math.random() * pool.length), t = pool[i];
    if (lvl.value === 'words') { var w = pool.slice(); for (var k = w.length - 1; k > 0; k--) { var j = Math.floor(Math.random() * (k + 1)), x = w[k]; w[k] = w[j]; w[j] = x; } t = w.slice(0, 14).join(' '); }
    if (lvl.value === 'long') t = pool.slice().sort(function () { return Math.random() - .5; }).slice(0, 3).join(' ');
    return t;
  }
  function render() {
    var v = inp.value, h = '';
    for (var i = 0; i < text.length; i++) {
      var c = text[i], cls = i < v.length ? (v[i] === c ? 'ok' : 'bad') : (i === v.length ? 'cur' : '');
      h += '<span class="' + cls + '">' + (c === ' ' ? ' ' : c.replace(/</g, '&lt;')) + '</span>';
    }
    box.innerHTML = h;
  }
  function stats() {
    var v = inp.value, ok = 0, bad = 0;
    for (var i = 0; i < v.length; i++) { if (v[i] === text[i]) ok++; else bad++; }
    var secs = start ? Math.max(1, (Date.now() - start) / 1000) : 0;
    var wpm = secs ? Math.round((ok / 5) / (secs / 60)) : 0, acc = v.length ? Math.round(ok / v.length * 100) : 100;
    S.w.textContent = wpm; S.a.textContent = acc + '%'; S.e.textContent = bad;
    S.t.textContent = Math.max(0, Math.ceil(limit - secs)) + 's';
    return { wpm: wpm, acc: acc, bad: bad, secs: secs, ok: ok };
  }
  function finish() {
    if (done) return; done = true; clearInterval(timer); inp.disabled = true;
    var s = stats(), lvlTxt = C.labels[s.wpm >= 35 ? 3 : s.wpm >= 22 ? 2 : s.wpm >= 12 ? 1 : 0];
    res.innerHTML = '<b>' + s.wpm + ' WPM</b> · ' + s.acc + '% accuracy · ' + s.bad + ' mistakes<br><span>' + lvlTxt + '</span>';
    res.hidden = false;
    try { var best = +localStorage.getItem('harf-best-' + C.lang) || 0; if (s.wpm > best && s.wpm < 200 && s.acc >= 85) { localStorage.setItem('harf-best-' + C.lang, s.wpm); res.innerHTML += '<br><em>New personal best!</em>'; } } catch (e) {}
    showBest();
  }
  function showBest() { var el = document.getElementById('tt-best'); if (!el) return; var b = 0; try { b = +localStorage.getItem('harf-best-' + C.lang) || 0; } catch (e) {} el.textContent = b ? b + ' WPM' : '—'; }
  function reset() {
    clearInterval(timer); start = 0; done = false; limit = +dur.value; text = pick();
    inp.value = ''; inp.disabled = false; res.hidden = true; render(); stats(); showBest();
    if (!matchMedia('(pointer:coarse)').matches) inp.focus();
  }
  function tick() { var s = stats(); if (s.secs >= limit) finish(); }
  function onInput() {
    if (done) return;
    if (!start && inp.value.length) { start = Date.now(); timer = setInterval(tick, 250); }
    if (inp.value.length > text.length) inp.value = inp.value.slice(0, text.length);
    render(); stats();
    if (inp.value.length === text.length) finish();
  }
  inp.addEventListener('input', onInput);
  inp.addEventListener('keydown', function (e) {
    if (!usePhon || e.ctrlKey || e.metaKey || e.altKey || e.isComposing || e.key.length !== 1) return;
    var k = e.key, lk = k.toLowerCase(), c = '';
    if (/[a-z]/.test(lk)) c = (e.shiftKey || k !== lk) ? (C.shift[lk] || C.map[lk]) : C.map[lk];
    else if (PUN[k]) c = PUN[k]; else return;
    if (!c) return; e.preventDefault();
    var s = inp.selectionStart, en = inp.selectionEnd; inp.setRangeText(c, s, en, 'end'); onInput();
  });
  inp.addEventListener('paste', function (e) { e.preventDefault(); });
  if (phon) phon.onclick = function () { usePhon = !usePhon; phon.textContent = usePhon ? '⌨️ English-key typing: on' : '⌨️ English-key typing: off (use your own ' + C.name + ' keyboard)'; inp.focus(); };
  document.getElementById('tt-new').onclick = reset; lvl.onchange = reset; dur.onchange = reset;
  if (matchMedia('(pointer:coarse)').matches && phon) { usePhon = false; phon.hidden = true; }
  reset();
})();
