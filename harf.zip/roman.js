/* Harf Roman typing: Roman Urdu/Pashto -> script. Urdu uses Google Input Tools (browser) with an offline rule fallback. */
(function(){
var L=window.HARF||{};var ta=document.getElementById('txt'),ri=document.getElementById('rom'),chips=document.getElementById('chips');if(!ta||!ri)return;
var UR={tri:{chh:'چھ',khh:'کھ'},di:{kh:'خ',gh:'غ',sh:'ش',ch:'چ',zh:'ژ',th:'تھ',ph:'پھ',bh:'بھ',dh:'دھ',jh:'جھ',rh:'رھ',aa:'ا',ee:'ی',oo:'و',ou:'و',ai:'ی',ay:'ی'},
 c:{b:'ب',p:'پ',t:'ت',j:'ج',d:'د',r:'ر',z:'ز',s:'س',f:'ف',q:'ق',k:'ک',g:'گ',l:'ل',m:'م',n:'ن',w:'و',v:'و',h:'ہ',y:'ی',c:'ک',x:'کس'},
 fin:{a:'ا',e:'ے',i:'ی',o:'و',u:'و'},mid:{a:'',e:'ی',i:'ی',o:'و',u:''},ini:{a:'ا',e:'ای',i:'ا',o:'او',u:'ا'},aaIni:'آ'};
var PS={tri:{},di:{kh:'خ',gh:'غ',sh:'ش',ch:'چ',zh:'ژ',ts:'څ',dz:'ځ',th:'ت',ph:'پ',aa:'ا',ee:'ي',ii:'ي',oo:'و',uu:'و',ey:'ې',ei:'ې',ay:'ی',ai:'ای',aw:'او',ow:'او'},
 c:{b:'ب',p:'پ',t:'ت',j:'ج',d:'د',r:'ر',z:'ز',s:'س',f:'ف',q:'ق',k:'ک',g:'ګ',l:'ل',m:'م',n:'ن',w:'و',v:'و',h:'ه',y:'ي',c:'ک',x:'ښ'},
 fin:{a:'ه',e:'ې',i:'ي',o:'و',u:'و'},mid:{a:'',e:'ې',i:'ي',o:'و',u:'و'},ini:{a:'ا',e:'ا',i:'ا',o:'او',u:'او'},aaIni:'آ'};
var PSD={salam:'سلام',pakhair:'پخير',pakhir:'پخير',khair:'خير',khayr:'خير',manana:'مننه',sta:'ستا',zama:'زما',za:'زه',ta:'ته',mung:'موږ',mog:'موږ',tasu:'تاسو',taso:'تاسو',hagha:'هغه',dagha:'دغه',da:'دا',de:'دې',dy:'دی',day:'دی',dey:'دی',hum:'هم',ham:'هم',aw:'او',ow:'او',ao:'او',ka:'که',kho:'خو',pa:'په',ke:'کې',key:'کې',kay:'کې',la:'له',sara:'سره',bia:'بیا',bya:'بیا',os:'اوس',wakht:'وخت',waqt:'وخت',kar:'کار',kaar:'کار',paisy:'پیسې',paise:'پیسې',dukan:'دوکان',bazar:'بازار',ghwaram:'غواړم',ghwari:'غواړې',wayam:'وایم',wayi:'وایي',shta:'شته',nishta:'نشته',lag:'لږ',lagh:'لږ',zwan:'ځوان',spin:'سپین',tor:'تور',sur:'سور',shin:'شین',kor:'کور',khalak:'خلک',khalq:'خلک',khuday:'خدای',khudai:'خدای',pakhto:'پښتو',pashto:'پښتو',pukhto:'پښتو',pakhtun:'پښتون',pashtun:'پښتون',pukhtun:'پښتون',afghanistan:'افغانستان',pekhawar:'پېښور',peshawar:'پېښور',kabul:'کابل',mor:'مور',plar:'پلار',wror:'ورور',khor:'خور',zoy:'زوی',zoe:'زوی',lur:'لور',ghar:'غر',oba:'اوبه',obe:'اوبه',dodai:'ډوډۍ',dodi:'ډوډۍ',chai:'چای',yaar:'یار',yar:'یار',meena:'مینه',mina:'مینه',zra:'زړه',stargy:'سترګې',stargey:'سترګې',starga:'سترګه',ghwag:'غوږ',las:'لاس',lus:'لس',sar:'سر',kitab:'کتاب',kha:'ښه',xa:'ښه',dera:'ډېره',der:'ډېر',loy:'لوی',warukay:'وړوکی',nan:'نن',saba:'سبا',parun:'پرون',sahar:'سهار',makham:'ماښام',maxam:'ماښام',shpa:'شپه',wraz:'ورځ',wraz:'ورځ',kal:'کال',miasht:'میاشت',myasht:'میاشت',hafta:'هفته',yaw:'یو',yao:'یو',dwa:'دوه',dre:'درې',dray:'درې',tsalor:'څلور',salor:'څلور',pinza:'پنځه',pinzha:'پنځه',shpag:'شپږ',owa:'اووه',ata:'اته',naha:'نهه',sal:'سل',zay:'ځای',dzay:'ځای',tsa:'څه',sa:'څه',tsanga:'څنګه',sanga:'څنګه',tsok:'څوک',sok:'څوک',cheri:'چېرې',chere:'چېرې',kala:'کله',wali:'ولې',wale:'ولې',ho:'هو',na:'نه',raza:'راځه',lar:'لار',watan:'وطن',jumat:'جومات',allah:'الله',alla:'الله',inshallah:'انشاءالله',mashallah:'ماشاءالله',janan:'جانان',gul:'ګل',gulona:'ګلونه',wada:'واده',khushala:'خوشاله',khoshala:'خوشاله',khapa:'خپه',jor:'جوړ',jur:'جوړ',ye:'یې',yey:'یې',yam:'یم',yu:'یو',shi:'شي',shay:'شی',kawam:'کوم',kawi:'کوي',kawe:'کوې',raghlam:'راغلم',raghla:'راغله',lar_sha:'لاړ شه',zam:'ځم',zi:'ځي',zey:'ځې',khabara:'خبره',khabare:'خبرې',ghag:'غږ',sandara:'سندره',tapa:'ټپه',tappa:'ټپه',watan:'وطن',ilm:'علم',ustaz:'استاذ',ustad:'استاد',maktab:'مکتب',school:'ښوونځی',xowanzay:'ښوونځی',doctor:'ډاکټر',dakter:'ډاکټر',mobile:'موبایل',phone:'فون',khwand:'خوند',khwaga:'خوږه',trikh:'تریخ',garam:'ګرم',sor:'سوړ',baran:'باران',wawra:'واوره',lmar:'لمر',spogmay:'سپوږمۍ',storay:'ستوری',asman:'آسمان',zmaka:'ځمکه',dunya:'دنیا',zhwand:'ژوند',marg:'مرګ',roogh:'روغ',rogh:'روغ',naragh:'ناروغ',nargh:'ناروغ',jorr:'جوړ',khudayyar:'خدای یار',pamaankhuday:'په مخه دې ښه',stalay:'ستړی',staray:'ستړی',mashay:'مه ستړی',ma:'مه',mah:'مه',kum:'کوم',hara:'هره',har:'هر',tol:'ټول',tola:'ټوله',sumra:'څومره',tsumra:'څومره',ziat:'زیات',zyat:'زیات',kam:'کم',nazde:'نږدې',lery:'لرې',lare:'لرې',dalta:'دلته',halta:'هلته',pore:'پورې',pore:'پورې',lande:'لاندې',bande:'باندې',mkhkay:'مخکې',wrusta:'وروسته'};
function translit(w,R){var lw=w.toLowerCase(),o='',i=0,n=lw.length;
 if(L.lang==='pashto'&&PSD[lw])return PSD[lw];
 while(i<n){var ch=lw[i],first=i===0,rest=n-i;
  if(rest>=3&&R.tri[lw.substr(i,3)]){o+=R.tri[lw.substr(i,3)];i+=3;continue}
  var two=lw.substr(i,2);
  if(two==='aa'){o+=first?R.aaIni:'ا';i+=2;continue}
  if(rest>=2&&R.di[two]&&!(first&&'aeiou'.indexOf(ch)>=0&&two!=='ai'&&two!=='aw'&&two!=='ow'&&two!=='ee'&&two!=='oo')){var v=R.di[two];if(first&&'aeiou'.indexOf(ch)>=0)v='ا'+v;o+=v;i+=2;continue}
  if('aeiou'.indexOf(ch)>=0){o+=first?R.ini[ch]:(i===n-1?R.fin[ch]:R.mid[ch]);i++;continue}
  if(R.c[ch]){o+=R.c[ch];i++;continue}
  if(/[0-9]/.test(ch)){o+=ch;i++;continue}
  i++}
 return o}
function rules(w){if(L.lang==='pashto')return translit(w,PS);var lw=w.toLowerCase(),E=[['ain','یں'],['ein','یں'],['oon','وں'],['iya','یہ'],['ai','ے'],['ay','ے'],['ah','ہ']];
 for(var i=0;i<E.length;i++){var e=E[i][0];if(lw.length>e.length&&lw.slice(-e.length)===e)return translit(lw.slice(0,-e.length),UR)+E[i][1]}return translit(lw,UR)}
var cache={},seq=0,last=null;
function suggest(w,cb){if(!w){cb([]);return}var key=L.lang+':'+w.toLowerCase();if(cache[key]){cb(cache[key]);return}
 var fb=rules(w),list=[];
 if(L.lang==='pashto'){var lw=w.toLowerCase();if(PSD[lw])list.push(PSD[lw]);Object.keys(PSD).forEach(function(k){if(list.length<5&&k!==lw&&k.indexOf(lw)===0&&list.indexOf(PSD[k])<0)list.push(PSD[k])});if(list.indexOf(fb)<0)list.push(fb);cache[key]=list;cb(list);return}
 var my=++seq,done=false,t=setTimeout(function(){if(!done){done=true;cb([fb])}},1800);
 fetch('https://inputtools.google.com/request?text='+encodeURIComponent(w)+'&itc=ur-t-i0-und&num=5&cp=0&cs=1&ie=utf-8&oe=utf-8&app=harf').then(function(r){return r.json()}).then(function(j){
  if(done&&my!==seq)return;clearTimeout(t);var c=(j[0]==='SUCCESS'&&j[1][0]&&j[1][0][1])||[];if(c.indexOf(fb)<0)c.push(fb);cache[key]=c;if(!done||my===seq){done=true;cb(c)}}).catch(function(){if(!done){done=true;clearTimeout(t);cb([fb])}})}
function ins(t){var s=ta.selectionStart,e=ta.selectionEnd;ta.setRangeText(t,s,e,'end');ta.dispatchEvent(new Event('input'))}
function showChips(list,onPick){chips.innerHTML=list.slice(0,6).map(function(c,i){return '<button type="button" class="chip'+(i===0?' top':'')+'" data-i="'+i+'">'+c.replace(/</g,'&lt;')+'</button>'}).join('');chips.onclick=function(e){var b=e.target.closest('.chip');if(b)onPick(list[+b.dataset.i])}}
var cur=[];
function commitWord(sep){var w=ri.value.trim();if(!w){if(sep)ins(sep);return}
 suggest(w,function(list){var pick=list[0]||rules(w);var start=ta.selectionStart;ins(pick+(sep||''));last={start:start,len:pick.length,list:list,sep:sep||''};
  showChips(list,function(alt){if(!last)return;var s=last.start;ta.setRangeText(alt,s,s+last.len,'end');ta.selectionStart=ta.selectionEnd=s+alt.length+last.sep.length;last.len=alt.length;ta.dispatchEvent(new Event('input'));ri.focus()})});
 ri.value=''}
var PUN={',':'،','.':'۔','?':'؟',';':'؛'};
ri.addEventListener('keydown',function(e){
 if(e.key===' '||e.key==='Enter'){e.preventDefault();commitWord(e.key===' '?' ':'\n');return}
 if(PUN[e.key]){e.preventDefault();commitWord('');ins(PUN[e.key]+' ');return}
 if(e.key==='Backspace'&&!ri.value){e.preventDefault();var s=ta.selectionStart;if(s>0){ta.setRangeText('',s-1,s,'end');ta.dispatchEvent(new Event('input'))}}});
var deb;ri.addEventListener('input',function(){var w=ri.value.trim();if(/\s/.test(ri.value)){var parts=ri.value.split(/\s+/);ri.value=parts.shift();commitWord(' ');ri.value=parts.join(' ');}
 clearTimeout(deb);deb=setTimeout(function(){var w2=ri.value.trim();if(!w2){return}suggest(w2,function(list){if(ri.value.trim()!==w2)return;last=null;showChips(list,function(alt){ri.value='';ins(alt+' ');chips.innerHTML='';ri.focus()})})},180)});
var go=document.getElementById('b-rom-go');if(go)go.onclick=function(){commitWord(' ');ri.focus()};
window.HARF_ROMAN=rules;
})();
