/* Harf keyboard engine: phonetic mapping + on-screen keys + tools */
(function(){
var L=window.HARF||{};var ta=document.getElementById('txt');if(!ta)return;
var MAP=L.map,SH=L.shift,ROWS=[['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['z','x','c','v','b','n','m']];
var PUN={',':'،','.':'۔','?':'؟',';':'؛','%':'٪'},DIG='۰۱۲۳۴۵۶۷۸۹';
var st={shift:false,on:true,dig:false};var K=document.getElementById('kb');
function store(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}
function ins(t){var s=ta.selectionStart,e=ta.selectionEnd;ta.setRangeText(t,s,e,'end');ta.dispatchEvent(new Event('input'))}
function bs(){var s=ta.selectionStart,e=ta.selectionEnd;if(s!==e){ta.setRangeText('',s,e,'end')}else if(s>0){var p=s-1;if(p>0&&/[\uDC00-\uDFFF]/.test(ta.value[p]))p--;ta.setRangeText('',p,s,'end')}ta.dispatchEvent(new Event('input'))}
function ch(k,sh){var m=sh?(SH[k]||MAP[k]):MAP[k];return m||''}
function render(){var h='';ROWS.forEach(function(r,i){h+='<div class="kr">';if(i===2)h+='<button type="button" class="k wide'+(st.shift?' act':'')+'" data-a="shift">⇧ Shift</button>';
 r.forEach(function(k){var c=ch(k,st.shift);h+='<button type="button" class="k" data-k="'+k+'"><b>'+(c||'&nbsp;')+'</b><i>'+(st.shift?k.toUpperCase():k)+'</i></button>'});
 if(i===2)h+='<button type="button" class="k wide" data-a="bs">⌫</button>';h+='</div>'});
 h+='<div class="kr"><button type="button" class="k" data-t="،"><b>،</b><i>,</i></button><button type="button" class="k" data-t="۔"><b>۔</b><i>.</i></button><button type="button" class="k" data-t="؟"><b>؟</b><i>?</i></button><button type="button" class="k space" data-t=" ">Space</button><button type="button" class="k" data-t="\n"><b>↵</b><i>Enter</i></button><button type="button" class="k" data-a="dig"><b>'+(st.dig?'۱۲۳':'123')+'</b><i>digits</i></button></div>';
 if(st.dig){h+='<div class="kr">';for(var d=1;d<=10;d++){var n=d%10;h+='<button type="button" class="k" data-t="'+DIG[n]+'"><b>'+DIG[n]+'</b><i>'+n+'</i></button>'}h+='</div>'}
 K.innerHTML=h}
K.addEventListener('mousedown',function(e){e.preventDefault()});
K.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var a=b.dataset.a;
 if(a==='shift'){st.shift=!st.shift;render();return}if(a==='bs'){bs();return}if(a==='dig'){st.dig=!st.dig;render();return}
 if(b.dataset.t!==undefined){ins(b.dataset.t)}else if(b.dataset.k){var c=ch(b.dataset.k,st.shift);if(c)ins(c);if(st.shift){st.shift=false;render()}}
 if(!touch)ta.focus()});
ta.addEventListener('keydown',function(e){if(!st.on||e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;var k=e.key;if(k.length!==1)return;var lk=k.toLowerCase(),c='';
 if(/[a-z]/.test(lk)){c=ch(lk,e.shiftKey||k!==lk)}else if(PUN[k])c=PUN[k];else if(/[0-9]/.test(k)&&st.dig)c=DIG[+k];else return;if(c){e.preventDefault();ins(c)}});
var touch=matchMedia('(pointer:coarse)').matches,ph=document.getElementById('b-phone');
function setPhone(on){ta.setAttribute('inputmode',on?'text':'none');if(ph)ph.textContent=on?'📱 Phone keyboard: on':'📱 Phone keyboard: off'}
if(ph){setPhone(!touch);ph.onclick=function(){setPhone(ta.getAttribute('inputmode')==='none');ta.focus()}}
var pt=document.getElementById('b-phon');if(pt)pt.onclick=function(){st.on=!st.on;pt.textContent=st.on?'⌨️ English-key typing: on':'⌨️ English-key typing: off';pt.classList.toggle('off',!st.on);ta.focus()};
var cnt=document.getElementById('cnt'),SK='harf-'+L.lang;
function upd(){var v=ta.value.trim();cnt.textContent=(v?v.split(/\s+/).length:0)+' words · '+ta.value.length+' characters';store(SK,ta.value)}
ta.addEventListener('input',upd);var sv=store(SK);if(sv)ta.value=sv;upd();
function flash(b,t){var o=b.textContent;b.textContent=t;setTimeout(function(){b.textContent=o},1400)}
document.getElementById('b-copy').onclick=function(){var b=this;(navigator.clipboard?navigator.clipboard.writeText(ta.value):Promise.reject()).then(function(){flash(b,'✓ Copied')},function(){ta.select();document.execCommand('copy');flash(b,'✓ Copied')})};
document.getElementById('b-clear').onclick=function(){if(ta.value&&!window.__c){window.__c=1;flash(this,'Tap again to clear');var s=this;setTimeout(function(){window.__c=0},1500);return}ta.value='';window.__c=0;upd();ta.focus()};
document.getElementById('b-txt').onclick=function(){var a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['﻿'+ta.value],{type:'text/plain;charset=utf-8'}));a.download=L.lang+'-text.txt';a.click()};
document.getElementById('b-wa').onclick=function(){window.open('https://wa.me/?text='+encodeURIComponent(ta.value),'_blank','noopener')};
document.getElementById('b-g').onclick=function(){window.open('https://www.google.com/search?q='+encodeURIComponent(ta.value),'_blank','noopener')};
document.getElementById('b-tr').onclick=function(){window.open('https://translate.google.com/?sl='+L.gt+'&tl=en&text='+encodeURIComponent(ta.value),'_blank','noopener')};
var fs=document.getElementById('fs'),ff=document.getElementById('ff');function font(){ta.style.fontSize=fs.value+'px';ta.style.fontFamily=ff.value;store('harf-fs',fs.value);store('harf-ff-'+L.lang,ff.value)}
if(store('harf-fs'))fs.value=store('harf-fs');if(store('harf-ff-'+L.lang))ff.value=store('harf-ff-'+L.lang);fs.oninput=font;ff.onchange=font;font();
document.getElementById('b-img').onclick=function(){var txt=ta.value.trim()||L.sample,fam=ff.value;document.fonts.load('48px '+fam).then(function(){
 var W=1080,pad=80,size=56,c=document.createElement('canvas'),x=c.getContext('2d');x.font=size+'px '+fam;x.direction='rtl';var lines=[];
 txt.split('\n').forEach(function(par){var w=par.split(' '),cur='';w.forEach(function(t){var tr=cur?cur+' '+t:t;if(x.measureText(tr).width>W-2*pad&&cur){lines.push(cur);cur=t}else cur=tr});lines.push(cur)});
 var lh=size*(/Nastaliq/.test(fam)?2.1:1.6),H=Math.max(1080,pad*2+lines.length*lh+60);c.width=W;c.height=H;x=c.getContext('2d');
 var g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,'#0f3d2e');g.addColorStop(1,'#13261f');x.fillStyle=g;x.fillRect(0,0,W,H);
 x.fillStyle='#fdf8ec';x.font=size+'px '+fam;x.direction='rtl';x.textAlign='right';x.textBaseline='middle';var y0=(H-lines.length*lh)/2+lh/2-20;
 lines.forEach(function(l,i){x.fillText(l,W-pad,y0+i*lh)});x.direction='ltr';x.textAlign='center';x.font='600 22px system-ui,sans-serif';x.fillStyle='#e8c46a';x.fillText(location.hostname,W/2,H-40);
 c.toBlob(function(b){var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=L.lang+'-text.png';a.click()})})};
var mic=document.getElementById('b-mic'),SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(mic){if(!SR){mic.hidden=true}else{var rec=null;mic.onclick=function(){if(rec){rec.stop();return}rec=new SR();rec.lang=L.sr;rec.interimResults=false;rec.continuous=true;
 rec.onresult=function(e){for(var i=e.resultIndex;i<e.results.length;i++)if(e.results[i].isFinal)ins((ta.value&&!/\s$/.test(ta.value)?' ':'')+e.results[i][0].transcript)};
 rec.onend=function(){rec=null;mic.classList.remove('rec');mic.textContent='🎤 Speak'};rec.onerror=function(){mic.textContent='🎤 Not available'};
 try{rec.start();mic.classList.add('rec');mic.textContent='■ Stop'}catch(e){rec=null}}}}
render();
})();
