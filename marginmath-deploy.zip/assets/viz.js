/* MarginMath charts. Reads each calculator's own inputs/outputs and draws live charts.
   No libraries; plain SVG + HTML. Runs after the page's inline calculator script. */
(function () {
  "use strict";
  if (document.body.classList.contains("embed")) return;
  var $ = function (id) { return document.getElementById(id); };
  var tool = document.querySelector("section.tool, .tool");
  if (!tool) return;
  var path = location.pathname.replace(/index\.html$/, "");

  /* ---------- helpers ---------- */
  function parseNum(t) { if (t == null) return NaN; t = String(t).replace(/[,\s$×x%]/g, ""); var neg = /^-|^−/.test(t); t = t.replace(/^[-−]/, ""); var v = parseFloat(t); return isFinite(v) ? (neg ? -v : v) : NaN; }
  function outNum(id) { var e = $(id); return e ? parseNum(e.textContent) : NaN; }
  function inNum(id) { var e = $(id); if (!e) return NaN; var v = parseFloat(e.value); return isFinite(v) ? v : NaN; }
  function inNum0(id) { var v = inNum(id); return isFinite(v) ? v : 0; }
  function fmtMoney(v, dp) { if (!isFinite(v)) return "—"; var d = dp == null ? (Math.abs(v) >= 1000 ? 0 : 2) : dp; return (v < 0 ? "−$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function fmtMoneyTick(v) { var a = Math.abs(v), s = v < 0 ? "−$" : "$"; if (a >= 1e6) return s + (a / 1e6).toFixed(a >= 1e7 ? 0 : 1) + "M"; if (a >= 1e4) return s + Math.round(a / 1e3) + "K"; if (a >= 1000) return s + a.toLocaleString("en-US", { maximumFractionDigits: 0 }); return s + (a % 1 ? a.toFixed(a < 10 ? 2 : 0) : a); }
  function fmtPct(v, dp) { if (!isFinite(v)) return "—"; return (Math.round(v * Math.pow(10, dp == null ? 1 : dp)) / Math.pow(10, dp == null ? 1 : dp)).toLocaleString("en-US") + "%"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function strip(html) { var d = document.createElement("div"); d.innerHTML = html; return d.textContent.trim(); }
  function niceStep(span, n) { var raw = span / Math.max(1, n), p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
  function ticks(lo, hi, n) { if (!(hi > lo)) { hi = lo + 1; } var st = niceStep(hi - lo, n || 5), a = Math.floor(lo / st) * st, out = []; for (var v = a; v <= hi + st * 1e-6; v += st) out.push(Math.round(v / st) * st); if (out[0] > lo) out.unshift(out[0] - st); if (out[out.length - 1] < hi) out.push(out[out.length - 1] + st); return out; }
  var SVGNS = "http://www.w3.org/2000/svg";
  function el(tag, attrs, parent) { var n = document.createElementNS(SVGNS, tag); for (var k in attrs) n.setAttribute(k, attrs[k]); if (parent) parent.appendChild(n); return n; }
  var ICON_WARN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>';
  var ICON_OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>';
  var FEE_COLORS = ["var(--v-f1)", "var(--v-f2)", "var(--v-f3)", "var(--v-f4)", "var(--v-f5)"];
  var DARK_TEXT = { "var(--v-f3)": 1, "var(--v-f5)": 1 }; // light fills take near-black labels

  /* ---------- shared tooltip ---------- */
  function tipFor(host) { var t = host.querySelector(".viz-tip"); if (!t) { t = document.createElement("div"); t.className = "viz-tip"; t.setAttribute("role", "status"); host.appendChild(t); } return t; }
  function showTip(host, html, x, y) { var t = tipFor(host); t.innerHTML = html; var w = host.clientWidth; t.style.left = Math.max(70, Math.min(w - 70, x)) + "px"; t.style.top = y + "px"; t.classList.add("show"); }
  function hideTip(host) { var t = host.querySelector(".viz-tip"); if (t) t.classList.remove("show"); }

  /* ---------- segmented bar + legend ---------- */
  function segBar(host, parts, opts) {
    opts = opts || {};
    var pos = parts.filter(function (p) { return p.value > 0.0049; }), total = pos.reduce(function (s, p) { return s + p.value; }, 0);
    var bar = host.querySelector(".viz-bar"), leg = host.querySelector(".viz-legend");
    if (!bar) { bar = document.createElement("div"); bar.className = "viz-bar"; bar.setAttribute("role", "img"); host.appendChild(bar); leg = document.createElement("ul"); leg.className = "viz-legend"; host.appendChild(leg); }
    bar.setAttribute("aria-label", (opts.title || "Breakdown") + ": " + pos.map(function (p) { return p.name + " " + fmtMoney(p.value) + " (" + fmtPct(p.value / total * 100) + ")"; }).join(", "));
    var barW = bar.clientWidth || 300;
    var html = "";
    pos.forEach(function (p) {
      var share = total ? p.value / total * 100 : 0, px = share / 100 * barW, label = fmtPct(share, share < 10 ? 1 : 0);
      var fits = px > label.length * 7 + 14;
      html += '<span class="seg' + (DARK_TEXT[p.color] ? " dark-text" : "") + '" tabindex="0" style="width:' + share.toFixed(3) + '%;background:' + p.color + '" data-n="' + esc(p.name) + '" data-v="' + p.value + '" data-s="' + share + '" aria-label="' + esc(p.name + ": " + fmtMoney(p.value) + ", " + fmtPct(share) + " of the total") + '">' + (fits ? label : "") + "</span>";
    });
    bar.innerHTML = html;
    var lh = "";
    parts.forEach(function (p) {
      if (!(p.value > 0.0049) && !p.always) return;
      lh += '<li><span class="sw" style="background:' + p.color + '"></span><span>' + esc(p.name) + '</span><span class="amt">' + fmtMoney(p.value) + '</span><span class="shr">' + (total && p.value > 0 ? fmtPct(p.value / total * 100) : "") + "</span></li>";
    });
    if (opts.totalLabel) lh += '<li class="total"><span></span><span>' + esc(opts.totalLabel) + '</span><span class="amt">' + fmtMoney(total) + '</span><span class="shr">100%</span></li>';
    leg.innerHTML = lh;
    var tipHost = opts.tipHost || host; tipHost.style.position = tipHost.style.position || "relative";
    Array.prototype.forEach.call(bar.children, function (s) {
      function on() { var r = s.getBoundingClientRect(), hr = tipHost.getBoundingClientRect(); showTip(tipHost, esc(s.dataset.n) + "<br><b>" + fmtMoney(+s.dataset.v) + "</b> · " + fmtPct(+s.dataset.s), r.left - hr.left + r.width / 2, r.top - hr.top); }
      s.addEventListener("mouseenter", on); s.addEventListener("focus", on);
      s.addEventListener("mouseleave", function () { hideTip(tipHost); }); s.addEventListener("blur", function () { hideTip(tipHost); });
    });
  }
  function splitBox(title) {
    var slip = tool.querySelector(".slip"); if (!slip) return null;
    var box = slip.querySelector(".viz-split");
    if (!box) {
      box = document.createElement("div"); box.className = "viz-split viz-root";
      box.innerHTML = "<h3>" + esc(title) + "</h3>";
      var anchor = slip.querySelector(".results");
      anchor.parentNode.insertBefore(box, anchor.nextSibling);
    }
    return box;
  }
  function setNote(box, html) { var n = box.querySelector(".viz-note"); if (!html) { if (n) n.remove(); return; } if (!n) { n = document.createElement("p"); n.className = "viz-note"; box.appendChild(n); } n.innerHTML = ICON_WARN + "<span>" + html + "</span>"; }

  /* ---------- wide panel ---------- */
  function panel(id, title, sub, keys) {
    var p = $(id);
    if (!p) {
      p = document.createElement("section"); p.id = id; p.className = "viz-panel viz-root"; p.setAttribute("aria-labelledby", id + "-h");
      p.innerHTML = '<div class="viz-head"><div><h2 id="' + id + '-h"></h2><p class="viz-sub"></p></div><ul class="viz-keys"></ul></div><div class="viz-chart"></div><div class="viz-foot"></div>';
      tool.parentNode.insertBefore(p, tool.nextSibling);
    }
    p.querySelector("h2").textContent = title;
    p.querySelector(".viz-sub").innerHTML = sub || "";
    p.querySelector(".viz-keys").innerHTML = (keys || []).map(function (k) { return '<li><i class="' + (k.dot ? "dot" : "") + '" style="background:' + k.color + '"></i>' + esc(k.name) + "</li>"; }).join("");
    return p;
  }
  function dataTable(p, cols, rows) {
    var f = p.querySelector(".viz-foot");
    var open = f.querySelector("details") && f.querySelector("details").open;
    f.innerHTML = '<span>Hover or tap the chart to read exact values.</span><details' + (open ? " open" : "") + '><summary>Show as a table</summary><table><thead><tr>' + cols.map(function (c, i) { return '<th class="' + (i ? "n" : "") + '">' + esc(c) + "</th>"; }).join("") + "</tr></thead><tbody>" + rows.map(function (r) { return "<tr>" + r.map(function (c, i) { return '<td class="' + (i ? "n" : "") + '">' + esc(c) + "</td>"; }).join("") + "</tr>"; }).join("") + "</tbody></table></details>";
  }

  /* ---------- line chart ---------- */
  function lineChart(host, o) {
    // o: {pts:[{x,y}], xFmt, yFmt, xTick, yTick, xTitle, yTitle, zeroLine, marks:[{x,y,label,sub,kind}], color, signed}
    var W = Math.max(300, host.clientWidth || 600), H = W < 520 ? 240 : 300;
    var m = { t: 22, r: 18, b: 40, l: 62 };
    var pts = o.pts.filter(function (p) { return isFinite(p.x) && isFinite(p.y); });
    if (pts.length < 2) { host.innerHTML = '<p class="viz-sub">Enter your numbers above to draw the chart.</p>'; return; }
    var xs = pts.map(function (p) { return p.x; }), ys = pts.map(function (p) { return p.y; });
    (o.marks || []).forEach(function (k) { if (isFinite(k.y)) ys.push(k.y); });
    var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
    if (o.zeroLine || o.yFromZero) { y0 = Math.min(0, y0); y1 = Math.max(0, y1); }
    var pad = (y1 - y0) * 0.08 || 1; if (y0 < 0 || !o.yFromZero) y0 -= pad; y1 += pad; if (o.yFromZero && y0 > -1e-9) y0 = 0;
    var yt = ticks(y0, y1, W < 520 ? 4 : 5); y0 = yt[0]; y1 = yt[yt.length - 1];
    var xt = ticks(x0, x1, W < 520 ? 4 : 7).filter(function (v) { return v >= x0 - 1e-9 && v <= x1 + 1e-9; });
    var iw = W - m.l - m.r, ih = H - m.t - m.b;
    function X(v) { return m.l + (v - x0) / (x1 - x0) * iw; }
    function Y(v) { return m.t + (1 - (v - y0) / (y1 - y0)) * ih; }
    host.innerHTML = "";
    var svg = el("svg", { viewBox: "0 0 " + W + " " + H, role: "img", "aria-label": o.aria || "Line chart" }, host);
    var uid = "c" + Math.random().toString(36).slice(2, 8), defs = el("defs", {}, svg);
    var zy = Y(0);
    var cpPos = el("clipPath", { id: uid + "p" }, defs); el("rect", { x: 0, y: 0, width: W, height: Math.max(0, Math.min(H, zy)) }, cpPos);
    var cpNeg = el("clipPath", { id: uid + "n" }, defs); el("rect", { x: 0, y: Math.max(0, zy), width: W, height: Math.max(0, H - zy) }, cpNeg);
    var g = el("g", {}, svg);
    yt.forEach(function (v) { el("line", { x1: m.l, x2: W - m.r, y1: Y(v), y2: Y(v), style: "stroke:var(--v-grid);stroke-width:1" }, g); var t = el("text", { x: m.l - 8, y: Y(v) + 4, "text-anchor": "end", class: "tick" }, g); t.textContent = (o.yTick || o.yFmt)(v); });
    xt.forEach(function (v) { var t = el("text", { x: X(v), y: H - m.b + 18, "text-anchor": "middle", class: "tick" }, g); t.textContent = (o.xTick || o.xFmt)(v); });
    el("line", { x1: m.l, x2: W - m.r, y1: H - m.b, y2: H - m.b, style: "stroke:var(--v-axis);stroke-width:1" }, g);
    if (o.xTitle) { var xtt = el("text", { x: m.l + iw / 2, y: H - 4, "text-anchor": "middle", class: "axis-title" }, g); xtt.textContent = o.xTitle; }
    if (o.yTitle) { var ytt = el("text", { x: 12, y: m.t + ih / 2, "text-anchor": "middle", class: "axis-title", transform: "rotate(-90 12 " + (m.t + ih / 2) + ")" }, g); ytt.textContent = o.yTitle; }
    if (o.zeroLine && y0 < 0 && y1 > 0) {
      el("line", { x1: m.l, x2: W - m.r, y1: zy, y2: zy, style: "stroke:var(--v-text2);stroke-width:1" }, g);
      var zl = el("text", { x: W - m.r, y: zy - 6, "text-anchor": "end", class: "lbl-sub" }, g); zl.textContent = o.zeroLabel || "$0 profit";
    }
    var line = pts.map(function (p, i) { return (i ? "L" : "M") + X(p.x).toFixed(1) + " " + Y(p.y).toFixed(1); }).join("");
    var base = o.signed ? zy : Y(Math.max(y0, 0));
    var area = line + "L" + X(pts[pts.length - 1].x).toFixed(1) + " " + base.toFixed(1) + "L" + X(pts[0].x).toFixed(1) + " " + base.toFixed(1) + "Z";
    var col = o.color || "var(--v-profit)";
    if (o.signed) {
      el("path", { d: area, style: "fill:var(--v-profit-wash)", "clip-path": "url(#" + uid + "p)" }, g);
      el("path", { d: area, style: "fill:var(--v-loss-wash)", "clip-path": "url(#" + uid + "n)" }, g);
      el("path", { d: line, style: "fill:none;stroke:var(--v-profit);stroke-width:2.25;stroke-linejoin:round;stroke-linecap:round", "clip-path": "url(#" + uid + "p)" }, g);
      el("path", { d: line, style: "fill:none;stroke:var(--v-loss);stroke-width:2.25;stroke-linejoin:round;stroke-linecap:round", "clip-path": "url(#" + uid + "n)" }, g);
    } else {
      el("path", { d: area, style: "fill:" + (o.wash || "var(--v-profit-wash)") }, g);
      el("path", { d: line, style: "fill:none;stroke:" + col + ";stroke-width:2.25;stroke-linejoin:round;stroke-linecap:round" }, g);
    }
    // marks (current value, break-even, target)
    var placed = [];
    (o.marks || []).forEach(function (k) {
      if (!isFinite(k.x) || !isFinite(k.y) || k.x < x0 || k.x > x1) return;
      var cx = X(k.x), cy = Y(k.y), main = k.kind === "main";
      if (main) el("line", { x1: cx, x2: cx, y1: cy, y2: H - m.b, style: "stroke:var(--v-text);stroke-width:1;opacity:.35" }, g);
      el("circle", { cx: cx, cy: cy, r: main ? 6 : 4.5, style: "fill:" + (k.color || (k.y < 0 && o.signed ? "var(--v-loss)" : col)) + ";stroke:var(--v-surface);stroke-width:2.5" }, g);
      // label placement: above unless near top; flip side near right edge; avoid overlaps
      var anchor = cx > W - m.r - 110 ? "end" : cx < m.l + 60 ? "start" : "middle", dx = anchor === "end" ? -10 : anchor === "start" ? 10 : 0;
      var ly = cy - (main ? 30 : 24); if (ly < 14) ly = cy + 26;
      placed.forEach(function (q) { if (Math.abs(q.x - cx) < 120 && Math.abs(q.y - ly) < 30) ly = q.y + (ly <= q.y ? -32 : 32); });
      if (ly > H - m.b - 6) ly = cy - 34;
      placed.push({ x: cx, y: ly });
      var t1 = el("text", { x: cx + dx, y: ly, "text-anchor": anchor, class: "lbl" }, g); t1.textContent = k.label;
      if (k.sub) { var t2 = el("text", { x: cx + dx, y: ly + 14, "text-anchor": anchor, class: "lbl-sub" }, g); t2.textContent = k.sub; }
    });
    // hover crosshair
    var cross = el("line", { y1: m.t, y2: H - m.b, style: "stroke:var(--v-text);stroke-width:1;opacity:0" }, g);
    var dot = el("circle", { r: 5, style: "fill:" + col + ";stroke:var(--v-surface);stroke-width:2.5;opacity:0" }, g);
    var hit = el("rect", { x: m.l, y: m.t, width: iw, height: ih, class: "hit" }, svg);
    function move(clientX) {
      var r = svg.getBoundingClientRect(), sx = (clientX - r.left) * (W / r.width), xv = x0 + (sx - m.l) / iw * (x1 - x0);
      var best = pts[0]; pts.forEach(function (p) { if (Math.abs(p.x - xv) < Math.abs(best.x - xv)) best = p; });
      var cx = X(best.x), cy = Y(best.y);
      cross.setAttribute("x1", cx); cross.setAttribute("x2", cx); cross.style.opacity = .25;
      dot.setAttribute("cx", cx); dot.setAttribute("cy", cy); dot.style.opacity = 1; dot.style.fill = o.signed && best.y < 0 ? "var(--v-loss)" : col;
      var scale = r.width / W;
      showTip(host, (o.tipX || o.xFmt)(best.x) + "<br><b>" + (o.tipY || o.yFmt)(best.y) + "</b>" + (o.tipExtra ? o.tipExtra(best) : ""), cx * scale, cy * scale);
    }
    function leave() { cross.style.opacity = 0; dot.style.opacity = 0; hideTip(host); }
    hit.addEventListener("mousemove", function (e) { move(e.clientX); });
    hit.addEventListener("touchstart", function (e) { move(e.touches[0].clientX); }, { passive: true });
    hit.addEventListener("touchmove", function (e) { move(e.touches[0].clientX); }, { passive: true });
    hit.addEventListener("mouseleave", leave); hit.addEventListener("touchend", function () { setTimeout(leave, 1600); });
  }

  /* ---------- fee breakdown from the slip table ---------- */
  function feeRows() {
    var out = [];
    var tb = $("o-table"); if (!tb) return out;
    tb.querySelectorAll("tbody tr").forEach(function (tr) {
      var td = tr.querySelectorAll("td"); if (td.length < 2) return;
      var name = td[0].textContent.trim(), v = parseNum(td[1].textContent);
      if (tr.querySelector("b") || /^total/i.test(name) || !isFinite(v)) return;
      out.push({ name: name.replace(/\s*\(.*?\)\s*/g, " ").replace(/\s*·.*$/, "").replace(/\s+/g, " ").trim(), full: name, value: v });
    });
    return out;
  }
  // Profit curve by temporarily re-running the page's own calculator at other prices.
  function sweepProfit(lo, hi, n, extraRev) {
    var pe = $("price"), orig = pe.value, pts = [];
    if (typeof window.calc !== "function") return pts;
    busy = true;
    try {
      for (var i = 0; i <= n; i++) {
        var x = lo + (hi - lo) * i / n; pe.value = x.toFixed(2); window.calc();
        pts.push({ x: x, y: outNum("o-profit"), m: outNum("o-margin") });
      }
    } finally { pe.value = orig; window.calc(); busy = false; }
    return pts;
  }

  /* ---------- page renderers ---------- */
  var R = {};

  R.fee = function (brand) {
    var P = inNum("price"); if (!isFinite(P) || P <= 0) return;
    var ship = inNum0("ship"), shipChg = inNum0("shipchg");
    var rows = feeRows();
    var profit = outNum("o-profit"), fees = rows.filter(function (r) { return !/product|shipping, prep|inbound/i.test(r.full); });
    var own;
    if (brand === "Amazon") { var ownRow = rows.find(function (r) { return /product/i.test(r.full); }); own = ownRow ? ownRow.value : 0; }
    else own = inNum0("cost") + inNum0("shipcost");
    var rev = brand === "Amazon" ? P + shipChg : P + ship;
    var parts = [{ name: brand === "Amazon" ? "Your costs (product, inbound, prep, ads)" : "Item & shipping cost", value: own, color: "var(--v-cost)", always: true }];
    var feeTotal = 0;
    fees.forEach(function (f, i) { if (f.value < 0) return; feeTotal += f.value; parts.push({ name: f.name, value: f.value, color: FEE_COLORS[i % FEE_COLORS.length] }); });
    var disc = fees.filter(function (f) { return f.value < 0; }).reduce(function (s, f) { return s + f.value; }, 0);
    if (disc) { // apply discounts to the first fee so the bar still sums to the order
      for (var j = 1; j < parts.length; j++) { var take = Math.min(parts[j].value, -disc); parts[j].value -= take; disc += take; if (disc >= 0) break; }
    }
    parts.push({ name: profit >= 0 ? "You keep (profit)" : "You keep", value: Math.max(0, profit), color: "var(--v-profit)", always: true });
    var box = splitBox("Where each " + fmtMoney(rev) + " sale goes");
    box.querySelector("h3").textContent = "Where each " + fmtMoney(rev) + " sale goes";
    segBar(box, parts, { title: "Where each sale goes", tipHost: box });
    setNote(box, profit < 0 ? "You lose <b>" + fmtMoney(-profit) + "</b> on each sale — fees and costs are bigger than the price." : "");

    // profit by price
    var be = outNum("o-be"), sug = outNum("o-suggest");
    var lo = Math.max(0.5, Math.min(P * 0.5, isFinite(be) ? be * 0.7 : P * 0.5)), hi = Math.max(P * 1.6, isFinite(sug) ? sug * 1.15 : 0, isFinite(be) ? be * 1.4 : 0);
    var pts = sweepProfit(lo, hi, W_SMALL() ? 40 : 64);
    var p = panel("viz-profit-curve", "Your profit at every price", "Each point re-runs this calculator with your costs and " + brand + "'s 2026 fees. Below the line you lose money.", [{ name: "Profit per sale", color: "var(--v-profit)" }, { name: "Loss", color: "var(--v-loss)" }]);
    var marks = [{ x: P, y: profit, label: "Your price " + fmtMoney(P), sub: "Profit " + fmtMoney(profit), kind: "main" }];
    if (isFinite(be) && Math.abs(be - P) / P > 0.04) marks.push({ x: be, y: 0, label: "Break-even", sub: fmtMoney(be), color: "var(--v-text2)" });
    if (isFinite(sug) && Math.abs(sug - P) / P > 0.04) { var sp = pts.reduce(function (a, b) { return Math.abs(b.x - sug) < Math.abs(a.x - sug) ? b : a; }, pts[0]); marks.push({ x: sug, y: sp ? sp.y : NaN, label: inNum("target") + "% margin", sub: fmtMoney(sug), color: "var(--v-f2)" }); }
    lineChart(p.querySelector(".viz-chart"), {
      pts: pts, signed: true, zeroLine: true, marks: marks,
      xFmt: function (v) { return fmtMoney(v); }, xTick: fmtMoneyTick, yFmt: function (v) { return fmtMoney(v); }, yTick: fmtMoneyTick,
      xTitle: "Item price", yTitle: "Profit per sale", tipX: function (v) { return "At " + fmtMoney(v); },
      tipY: function (v) { return fmtMoney(v) + (v < 0 ? " loss" : " profit"); },
      tipExtra: function (pt) { return isFinite(pt.m) ? " · " + fmtPct(pt.m) + " margin" : ""; },
      aria: "Profit per sale at prices from " + fmtMoney(lo) + " to " + fmtMoney(hi)
    });
    var step = Math.max(1, Math.round(pts.length / 10));
    dataTable(p, ["Price", "Profit", "Margin"], pts.filter(function (_, i) { return i % step === 0; }).map(function (q) { return [fmtMoney(q.x), fmtMoney(q.y), fmtPct(q.m)]; }));
  };

  function marginCurve(p, cur, xMax, mode) {
    // mode 'markup': x=markup y=margin ; mode 'margin': x=margin y=markup
    var pts = [], n = 90;
    for (var i = 0; i <= n; i++) {
      var x = xMax * i / n, y = mode === "markup" ? x / (100 + x) * 100 : (x >= 99.9 ? NaN : x / (100 - x) * 100);
      pts.push({ x: x, y: y });
    }
    return pts;
  }

  R.markup = function () {
    var C = inNum("cost"), P = inNum("price"), mk = inNum("markup");
    if (isFinite(C) && isFinite(P) && C >= 0 && P > 0) {
      var box = splitBox("What your " + fmtMoney(P) + " price is made of");
      box.querySelector("h3").textContent = "What your " + fmtMoney(P) + " price is made of";
      segBar(box, [{ name: "Cost", value: Math.min(C, P), color: "var(--v-cost)", always: true }, { name: "Profit", value: Math.max(0, P - C), color: "var(--v-profit)", always: true }], { title: "Price breakdown", tipHost: box });
      setNote(box, P < C ? "Selling below cost: you lose <b>" + fmtMoney(C - P) + "</b> per unit." : "");
    }
    if (!isFinite(mk) && isFinite(C) && C > 0 && isFinite(P)) mk = (P - C) / C * 100;
    var xMax = Math.max(300, isFinite(mk) ? Math.ceil(mk * 1.25 / 50) * 50 : 300);
    var p = panel("viz-markup-curve", "Markup vs. profit margin", "The same profit looks bigger as a markup than as a margin. Margin can never reach 100% — markup can.", [{ name: "Profit margin", color: "var(--v-profit)" }]);
    var pts = marginCurve(p, mk, xMax, "markup");
    var marks = [];
    if (isFinite(mk) && mk >= 0) marks.push({ x: mk, y: mk / (100 + mk) * 100, label: fmtPct(mk) + " markup", sub: "= " + fmtPct(mk / (100 + mk) * 100) + " margin", kind: "main" });
    if (!isFinite(mk) || Math.abs(mk - 100) > 15) marks.push({ x: 100, y: 50, label: "Keystone", sub: "100% → 50%", color: "var(--v-text2)" });
    lineChart(p.querySelector(".viz-chart"), { pts: pts, marks: marks, yFromZero: true, xFmt: function (v) { return fmtPct(v, 0) + " markup"; }, xTick: function (v) { return fmtPct(v, 0); }, yFmt: function (v) { return fmtPct(v) + " margin"; }, yTick: function (v) { return fmtPct(v, 0); }, xTitle: "Markup", yTitle: "Profit margin", aria: "Profit margin for markups from 0 to " + xMax + " percent" });
    dataTable(p, ["Markup", "Margin", isFinite(C) && C > 0 ? "Price on your cost" : "Price on $100 cost"], [10, 20, 25, 30, 40, 50, 75, 100, 150, 200, 300].map(function (k) { var c = isFinite(C) && C > 0 ? C : 100; return [fmtPct(k, 0), fmtPct(k / (100 + k) * 100), fmtMoney(c * (1 + k / 100))]; }));
  };

  R.margin = function () {
    var C = inNum("cost"), P = inNum("price"), M = inNum("margin"), q = inNum("qty"); if (!isFinite(q) || q <= 0) q = 1;
    if (isFinite(C) && isFinite(P) && P > 0) {
      var t = q > 1 ? "Your " + q.toLocaleString() + " units: " + fmtMoney(P * q) + " in sales" : "What your " + fmtMoney(P) + " price is made of";
      var box = splitBox(t); box.querySelector("h3").textContent = t;
      segBar(box, [{ name: q > 1 ? "Total cost" : "Cost", value: Math.min(C, P) * q, color: "var(--v-cost)", always: true }, { name: q > 1 ? "Total profit" : "Profit", value: Math.max(0, P - C) * q, color: "var(--v-profit)", always: true }], { title: "Revenue breakdown", tipHost: box });
      setNote(box, P < C ? "Selling below cost: you lose <b>" + fmtMoney((C - P) * q) + "</b>." : "");
    }
    if (!isFinite(M) && isFinite(C) && isFinite(P) && P > 0) M = (P - C) / P * 100;
    if (!(isFinite(C) && C > 0)) return;
    var p = panel("viz-margin-curve", "Price you need for each margin on a " + fmtMoney(C) + " cost", "Every extra point of margin costs more than the last — past 60% the price climbs steeply.", [{ name: "Selling price", color: "var(--v-f2)" }]);
    var pts = []; for (var i = 0; i <= 80; i++) { var m = 85 * i / 80; pts.push({ x: m, y: C / (1 - m / 100) }); }
    var marks = []; if (isFinite(M) && M >= 0 && M <= 85) marks.push({ x: M, y: C / (1 - M / 100), label: fmtPct(M) + " margin", sub: "Price " + fmtMoney(C / (1 - M / 100)), kind: "main", color: "var(--v-f2)" });
    lineChart(p.querySelector(".viz-chart"), { pts: pts, marks: marks, color: "var(--v-f2)", wash: "rgba(42,120,214,.08)", yFromZero: true, xFmt: function (v) { return fmtPct(v) + " margin"; }, xTick: function (v) { return fmtPct(v, 0); }, yFmt: function (v) { return fmtMoney(v); }, yTick: fmtMoneyTick, xTitle: "Profit margin", yTitle: "Selling price", tipY: function (v) { return "Charge " + fmtMoney(v); }, tipExtra: function (pt) { return " · " + fmtMoney(pt.y - C) + " profit"; }, aria: "Selling price needed for profit margins from 0 to 85 percent" });
    dataTable(p, ["Margin", "Price", "Profit"], [10, 20, 25, 30, 40, 50, 60, 70, 80].map(function (k) { var pr = C / (1 - k / 100); return [fmtPct(k, 0), fmtMoney(pr), fmtMoney(pr - C)]; }));
  };

  R.convert = function () {
    var M = inNum("margin"), K = inNum("markup");
    if (!isFinite(M) && isFinite(K)) M = K / (100 + K) * 100;
    if (isFinite(M) && M < 100) {
      var box = splitBox("On a $100 sale");
      segBar(box, [{ name: "Cost", value: 100 - Math.max(0, M), color: "var(--v-cost)", always: true }, { name: "Profit", value: Math.max(0, M), color: "var(--v-profit)", always: true }], { title: "On a $100 sale", tipHost: box });
    }
    var p = panel("viz-convert-curve", "How margin turns into markup", "Low margins convert almost one-to-one. High margins need huge markups: 80% margin is a 400% markup.", [{ name: "Markup", color: "var(--v-f4)" }]);
    var pts = marginCurve(p, M, 85, "margin");
    var marks = []; if (isFinite(M) && M >= 0 && M <= 85) marks.push({ x: M, y: M / (100 - M) * 100, label: fmtPct(M) + " margin", sub: "= " + fmtPct(M / (100 - M) * 100) + " markup", kind: "main", color: "var(--v-f4)" });
    lineChart(p.querySelector(".viz-chart"), { pts: pts, marks: marks, color: "var(--v-f4)", wash: "rgba(98,80,214,.08)", yFromZero: true, xFmt: function (v) { return fmtPct(v) + " margin"; }, xTick: function (v) { return fmtPct(v, 0); }, yFmt: function (v) { return fmtPct(v) + " markup"; }, yTick: function (v) { return fmtPct(v, 0); }, xTitle: "Profit margin", yTitle: "Markup", aria: "Markup needed for profit margins from 0 to 85 percent" });
    dataTable(p, ["Margin", "Markup", "Multiplier"], [5, 10, 15, 20, 25, 30, 33.33, 40, 50, 60, 70, 75, 80].map(function (k) { return [fmtPct(k), fmtPct(k / (100 - k) * 100), (100 / (100 - k)).toFixed(2) + "×"]; }));
  };

  R.acos = function () {
    var acos = outNum("o-acos"), be = outNum("o-be"), tgt = outNum("o-tgt");
    if (isFinite(acos) && isFinite(be)) {
      var box = splitBox("Every $100 of ad sales");
      var cogs = Math.max(0, 100 - Math.max(be, 0)), spend = acos, prof = be - acos;
      segBar(box, [{ name: "Product cost & Amazon fees", value: Math.min(cogs, 100), color: "var(--v-cost)", always: true }, { name: "Ad spend (ACoS)", value: Math.max(0, Math.min(spend, 100 - cogs)), color: "var(--v-f1)", always: true }, { name: "Profit after ads", value: Math.max(0, prof), color: "var(--v-profit)", always: true }], { title: "Every $100 of ad sales", tipHost: box });
      setNote(box, prof < 0 ? "Ads cost more than this product earns: you lose about <b>" + fmtMoney(-prof) + "</b> per $100 of ad sales." : "");
    }
    if (!isFinite(acos)) return;
    var p = panel("viz-acos-scale", "Where your ACoS sits", "Green is profitable after your target margin, amber still makes money but less than you want, red loses money on every ad sale.", []);
    var c = p.querySelector(".viz-chart");
    var max = Math.max(isFinite(be) ? be * 1.5 : 0, acos * 1.25, 40); max = Math.ceil(max / 10) * 10;
    var z1 = isFinite(tgt) ? Math.max(0, Math.min(tgt, max)) : NaN, z2 = isFinite(be) ? Math.max(0, Math.min(be, max)) : NaN;
    var state = !isFinite(be) ? "" : acos <= (isFinite(tgt) ? tgt : be) ? "good" : acos <= be ? "thin" : "loss";
    var zones = "";
    if (isFinite(z1) && isFinite(z2)) {
      zones = '<span class="zone" style="width:' + (z1 / max * 100) + '%;background:var(--v-profit)"></span><span class="zone" style="width:' + ((z2 - z1) / max * 100) + '%;background:var(--v-warn)"></span><span class="zone" style="flex:1;background:var(--v-loss)"></span>';
    } else zones = '<span class="zone" style="flex:1;background:var(--v-grid)"></span>';
    var pinX = Math.min(acos, max) / max * 100;
    var label = { good: [ICON_OK, "Profitable", "var(--v-profit)"], thin: [ICON_WARN, "Profitable, below target", "var(--v-warn)"], loss: [ICON_WARN, "Losing money on ads", "var(--v-loss)"] }[state];
    c.innerHTML = (label ? '<p class="viz-status" style="color:' + label[2] + '">' + label[0] + "<span>" + label[1] + "</span></p>" : "") +
      '<div class="viz-scale" role="img" aria-label="ACoS ' + fmtPct(acos) + (isFinite(be) ? ", break-even " + fmtPct(be) : "") + (isFinite(tgt) ? ", target " + fmtPct(tgt) : "") + '"><div class="rail">' + zones + "</div>" +
      (isFinite(z1) ? '<span class="mark" style="left:' + (z1 / max * 100) + '%">Target<br>' + fmtPct(tgt) + "</span>" : "") +
      (isFinite(z2) ? '<span class="mark" style="left:' + (z2 / max * 100) + '%">Break-even<br>' + fmtPct(be) + "</span>" : "") +
      '<span class="pin" style="left:' + pinX + '%"><span class="tag">ACoS ' + fmtPct(acos) + '</span><span class="stem"></span></span></div>' +
      '<div class="viz-foot" style="margin-top:0"><span>0%</span><span>' + max + "%</span></div>";
  };

  R.compare = function () {
    var tb = $("o-table"); if (!tb || !tb.querySelector("tbody tr")) return;
    var get = function (rx) { var tr = Array.prototype.find.call(tb.querySelectorAll("tbody tr"), function (r) { return rx.test(r.cells[0].textContent); }); return tr ? [1, 2, 3].map(function (i) { return parseNum(tr.cells[i].textContent); }) : [NaN, NaN, NaN]; };
    var rev = get(/customer pays/i), fee = get(/marketplace fees/i), keep = get(/you keep/i);
    var names = ["Amazon FBA", "eBay", "Etsy"], subs = ["FBA ships", "You ship", "You ship"];
    var max = Math.max.apply(null, rev.filter(isFinite)) || 1;
    var best = -1, bv = -Infinity; keep.forEach(function (k, i) { if (isFinite(k) && k > bv) { bv = k; best = i; } });
    var p = panel("viz-compare", "Same product, three marketplaces", "Bar length is what the customer pays. Orange is the marketplace's cut, gray is your item and shipping cost, green is what you keep.", [{ name: "Marketplace fees", color: "var(--v-f1)", dot: true }, { name: "Your costs", color: "var(--v-cost)", dot: true }, { name: "You keep", color: "var(--v-profit)", dot: true }]);
    var c = p.querySelector(".viz-chart");
    c.innerHTML = '<div class="viz-rows"></div>';
    var rowsHost = c.firstChild, table = [];
    names.forEach(function (n, i) {
      var row = document.createElement("div"); row.className = "viz-row";
      var ok = isFinite(rev[i]) && isFinite(fee[i]) && isFinite(keep[i]);
      row.innerHTML = '<div class="name">' + n + "<small>" + subs[i] + "</small>" + (i === best ? '<span class="viz-badge">Best payout</span>' : "") + '</div><div class="track"></div><div class="keep' + (ok && keep[i] < 0 ? " neg" : "") + '">' + (ok ? fmtMoney(keep[i]) : "Add size") + "</div>";
      rowsHost.appendChild(row);
      if (!ok) return;
      var cost = Math.max(0, rev[i] - fee[i] - Math.max(0, keep[i]));
      var tr = row.querySelector(".track"); var holder = document.createElement("div"); holder.style.width = (rev[i] / max * 100) + "%"; tr.appendChild(holder);
      segBar(holder, [{ name: n + " fees", value: fee[i], color: "var(--v-f1)" }, { name: "Your costs", value: cost, color: "var(--v-cost)" }, { name: "You keep", value: Math.max(0, keep[i]), color: "var(--v-profit)" }], { title: n, tipHost: c });
      var lg = holder.querySelector(".viz-legend"); if (lg) lg.remove();
      table.push([n, fmtMoney(rev[i]), fmtMoney(fee[i]), fmtMoney(cost), fmtMoney(keep[i])]);
    });
    dataTable(p, ["Marketplace", "Customer pays", "Fees", "Your costs", "You keep"], table);
  };

  var page = {
    "/": R.markup, "/profit-margin-calculator/": R.margin, "/margin-to-markup-calculator/": R.convert,
    "/etsy-fee-calculator/": function () { R.fee("Etsy"); }, "/ebay-fee-calculator/": function () { R.fee("eBay"); },
    "/amazon-fba-calculator/": function () { R.fee("Amazon"); }, "/acos-calculator/": R.acos, "/amazon-vs-ebay-vs-etsy-fees/": R.compare
  }[path];
  if (!page) return;
  function W_SMALL() { return window.innerWidth < 600; }

  var busy = false, queued = false;
  function render() { queued = false; if (busy) return; try { page(); } catch (e) { if (window.console) console.warn("viz", e); } }
  function schedule() { if (busy || queued) return; queued = true; (window.requestAnimationFrame || setTimeout)(render); }
  tool.addEventListener("input", schedule); tool.addEventListener("change", schedule); tool.addEventListener("click", function (e) { if (e.target.closest("button")) setTimeout(schedule, 0); });
  var rw; window.addEventListener("resize", function () { clearTimeout(rw); rw = setTimeout(schedule, 150); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(schedule);
  render();
})();
