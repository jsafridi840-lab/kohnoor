/* MarginMath dashboard layer v1: KPI tiles + charts that mirror each calculator's own results */
(function () {
  var tool = document.querySelector('section.tool');
  var out = tool && tool.querySelector('.tool-out');
  var slip = out && out.querySelector('.slip');
  if (!tool || !out || !slip) return;
  tool.classList.add('mm-dash');
  var path = location.pathname.replace(/index\.html$/, '');
  var G = 'var(--green)', Y = 'var(--tag)', R = 'var(--loss)', N = 'var(--rule-strong)';

  function $(id) { return document.getElementById(id); }
  function txt(id) { var e = $(id); return e ? (e.textContent || '').trim() : ''; }
  function val(id) { // number from an output or input; null if empty
    var e = $(id); if (!e) return null;
    var s = (e.value !== undefined && e.tagName === 'INPUT') ? e.value : e.textContent;
    if (!s || /—|–/.test(s) && !/\d/.test(s)) return null;
    var neg = /^\s*[−-]/.test(s) || /\(.*\)/.test(s);
    var n = parseFloat(String(s).replace(/[^0-9.]/g, ''));
    if (isNaN(n)) return null; return neg ? -n : n;
  }
  function money(n) { var a = Math.abs(n); return (n < 0 ? '−$' : '$') + a.toLocaleString('en-US', { minimumFractionDigits: a < 1000 ? 2 : 0, maximumFractionDigits: a < 1000 ? 2 : 0 }); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ---- KPI tiles mirror the first four result rows ----
  var stats = [].slice.call(slip.querySelectorAll('.results .stat')).slice(0, 4);
  var kp = document.createElement('div'); kp.className = 'mm-kpis';
  stats.forEach(function (s, i) {
    var o = s.querySelector('output'); s.classList.add('mm-mirrored');
    var d = document.createElement('div'); d.className = 'mm-kpi' + (i === 0 ? ' main' : '');
    d.innerHTML = '<span>' + esc(s.querySelector('span').textContent) + '</span><b data-src="' + o.id + '">—</b>';
    kp.appendChild(d);
  });
  kp.style.gridTemplateColumns = 'repeat(' + stats.length + ',minmax(0,1fr))'; if (stats.length === 4) kp.style.gridTemplateColumns = '';
  var charts = document.createElement('div'); charts.className = 'mm-charts';
  out.insertBefore(charts, slip); out.insertBefore(kp, charts);

  var EMPTY = '<div class="mm-empty"><svg width="54" height="54" viewBox="0 0 54 54"><rect x="4" y="30" width="10" height="20" rx="3" fill="var(--green-wash)"/><rect x="20" y="18" width="10" height="32" rx="3" fill="var(--green-wash)"/><rect x="36" y="6" width="10" height="44" rx="3" fill="var(--green-wash)"/></svg><span>Enter your numbers and your charts appear here, live.</span></div>';

  function donut(title, segs, center, sub) {
    var tot = segs.reduce(function (a, s) { return a + Math.max(0, s.v); }, 0);
    if (!tot) return panel(title, EMPTY);
    var C = 2 * Math.PI * 70, off = 0, arcs = '';
    segs.forEach(function (s) {
      var f = Math.max(0, s.v) / tot; if (!f) return;
      arcs += '<circle cx="100" cy="100" r="70" fill="none" stroke="' + s.c + '" stroke-width="26" stroke-dasharray="' + Math.max(C * f - 1.5, 1).toFixed(1) + ' ' + C.toFixed(1) + '" stroke-dashoffset="' + (-off).toFixed(1) + '" transform="rotate(-90 100 100)"/>';
      off += C * f;
    });
    var leg = segs.map(function (s) { return '<li><i class="mm-sw" style="background:' + s.c + '"></i>' + esc(s.l) + '<b>' + (s.t || money(s.v)) + '</b></li>'; }).join('');
    return panel(title, '<div class="mm-donut"><svg viewBox="0 0 200 200" role="img" aria-label="' + esc(title) + '"><circle cx="100" cy="100" r="70" fill="none" stroke="var(--field)" stroke-width="26"/>' + arcs +
      '<text x="100" y="98" text-anchor="middle" font-size="25" font-weight="800" fill="var(--ink)">' + esc(center) + '</text><text x="100" y="120" text-anchor="middle" font-size="11" fill="var(--muted)">' + esc(sub) + '</text></svg><ul class="mm-legend">' + leg + '</ul></div>');
  }
  function bars(title, rows, fmt) {
    rows = rows.filter(function (r) { return r.v !== null && !isNaN(r.v); });
    if (!rows.length) return panel(title, EMPTY);
    var mx = Math.max.apply(null, rows.map(function (r) { return Math.abs(r.v); })) || 1;
    return panel(title, '<div class="mm-bars">' + rows.map(function (r) {
      return '<div class="mm-bar"><span title="' + esc(r.l) + '">' + esc(r.l) + '</span><div class="mm-track"><i class="' + (r.cls || (r.v < 0 ? 'red' : '')) + '" style="width:' + (Math.abs(r.v) / mx * 100).toFixed(1) + '%"></i></div><b>' + (fmt ? fmt(r.v) : money(r.v)) + '</b></div>';
    }).join('') + '</div>');
  }
  function panel(t, body) { return '<div class="mm-panel"><div class="mm-pt">' + esc(t) + '</div>' + body + '</div>'; }
  function feeRows() {
    return [].slice.call(document.querySelectorAll('#o-table tbody tr')).map(function (tr) {
      var td = tr.querySelectorAll('td'); if (td.length < 2) return null;
      var s = td[td.length - 1].textContent, n = parseFloat(s.replace(/[^0-9.]/g, ''));
      return { l: td[0].textContent.trim(), v: isNaN(n) ? null : n, cls: 'gold' };
    }).filter(function (r) { return r && r.v > 0 && !/^total/i.test(r.l); });
  }
  function pctFmt(v) { return v.toFixed(1) + '%'; }

  function curve(title, fx, xMax, xv, xl, yl) {
    var W = 640, H = 220, L = 46, Rr = 14, T = 26, B = 30, n = 100, ys = [], i;
    for (i = 0; i <= n; i++) ys.push(fx(xMax * i / n));
    var ymax = Math.max.apply(null, ys) || 1;
    var P = function (x, y) { return [L + (W - L - Rr) * x / xMax, T + (H - T - B) * (1 - y / ymax)]; };
    var d = 'M' + ys.map(function (y, k) { var p = P(xMax * k / n, y); return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join('L');
    var g = '';
    for (i = 0; i <= 4; i++) { var yy = T + (H - T - B) * i / 4; g += '<line x1="' + L + '" x2="' + (W - Rr) + '" y1="' + yy + '" y2="' + yy + '" stroke="var(--rule)"/><text x="' + (L - 6) + '" y="' + (yy + 4) + '" font-size="11" text-anchor="end" fill="var(--muted)">' + Math.round(ymax * (1 - i / 4)) + yl + '</text>'; }
    for (i = 0; i <= 4; i++) { var xx = L + (W - L - Rr) * i / 4; g += '<text x="' + xx + '" y="' + (H - 10) + '" font-size="11" text-anchor="' + (i ? (i === 4 ? 'end' : 'middle') : 'start') + '" fill="var(--muted)">' + Math.round(xMax * i / 4) + xl + '</text>'; }
    var mk = '';
    if (xv !== null && xv >= 0 && xv <= xMax) {
      var p = P(xv, fx(xv)), lx = Math.min(Math.max(p[0], L + 70), W - Rr - 70);
      mk = '<line x1="' + p[0] + '" x2="' + p[0] + '" y1="' + T + '" y2="' + (H - B) + '" stroke="' + Y + '" stroke-width="2" stroke-dasharray="5 4"/><circle cx="' + p[0] + '" cy="' + p[1] + '" r="7" fill="' + Y + '" stroke="var(--ink)" stroke-width="1.5"/>' +
        '<rect x="' + (lx - 70) + '" y="2" width="140" height="20" rx="10" fill="var(--ink)"/><text x="' + lx + '" y="16" font-size="11.5" font-weight="700" text-anchor="middle" fill="var(--card)">You: ' + xv.toFixed(1) + xl + ' → ' + fx(xv).toFixed(1) + yl + '</text>';
    }
    return panel(title, '<svg class="mm-svg" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(title) + '"><defs><linearGradient id="mmg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--green)" stop-opacity=".28"/><stop offset="1" stop-color="var(--green)" stop-opacity=".02"/></linearGradient></defs>' + g +
      '<path d="' + d + 'L' + (W - Rr) + ',' + (H - B) + 'L' + L + ',' + (H - B) + 'Z" fill="url(#mmg)"/><path d="' + d + '" fill="none" stroke="' + G + '" stroke-width="3"/>' + mk + '</svg>');
  }
  function gauge(title, items, scaleMax) {
    var have = items.filter(function (i) { return i.v !== null; });
    if (!have.length) return panel(title, EMPTY);
    var W = 640, L = 20, Rr = 20, y = 86, mx = Math.max(scaleMax, Math.max.apply(null, have.map(function (i) { return i.v; })) * 1.15);
    var X = function (v) { return L + (W - L - Rr) * Math.min(v, mx) / mx; };
    var s = '<rect x="' + L + '" y="' + (y - 9) + '" width="' + (W - L - Rr) + '" height="18" rx="9" fill="var(--field)"/>';
    var be = items.filter(function (i) { return i.k === 'be'; })[0];
    if (be && be.v !== null) s += '<rect x="' + L + '" y="' + (y - 9) + '" width="' + (X(be.v) - L) + '" height="18" rx="9" fill="var(--green)" fill-opacity=".22"/>';
    have.forEach(function (it, idx) {
      var x = X(it.v), ly = [y - 26, y + 36, y - 50][idx % 3];
      s += '<line x1="' + x + '" x2="' + x + '" y1="' + (y - 16) + '" y2="' + (y + 16) + '" stroke="' + it.c + '" stroke-width="' + (it.k === 'acos' ? 5 : 3) + '" stroke-linecap="round"/>' +
        '<text x="' + Math.min(Math.max(x, 60), W - 60) + '" y="' + ly + '" font-size="12" font-weight="700" text-anchor="middle" fill="var(--ink)">' + esc(it.l) + ' ' + it.v.toFixed(1) + '%</text>';
    });
    s += '<text x="' + L + '" y="' + (y + 58) + '" font-size="11" fill="var(--muted)">0%</text><text x="' + (W - Rr) + '" y="' + (y + 52) + '" font-size="11" text-anchor="end" fill="var(--muted)">' + Math.round(mx) + '%</text>';
    return panel(title, '<svg class="mm-svg" viewBox="0 0 ' + W + ' 150" role="img" aria-label="' + esc(title) + '">' + s + '</svg><p class="small" style="margin:6px 0 0">Shaded area = profitable zone (below break-even ACoS).</p>');
  }

  var VIEWS = {
    '/': function () {
      var c = val('cost'), p = val('price') !== null ? val('price') : null, pr = val('o-profit');
      if (p === null && c !== null && pr !== null) p = c + pr;
      return donut('Where your selling price goes', [{ l: 'Your cost', v: c || 0, c: N }, { l: 'Your profit', v: pr || 0, c: G }], txt('o-margin') || '—', 'profit margin') +
        bars('Price at common markups', [25, 50, 75, 100, 150].map(function (m) { return { l: m + '% markup', v: c ? c * (1 + m / 100) : null, cls: m === 100 ? 'gold' : '' }; }));
    },
    '/profit-margin-calculator/': function () {
      var c = val('cost'), pr = val('o-profit'), p = val('price'); if (p === null && c !== null && pr !== null) p = c + pr;
      var q = val('qty') || 1;
      return donut('Where your selling price goes', [{ l: 'Your cost', v: c || 0, c: N }, { l: 'Gross profit', v: pr || 0, c: G }], txt('o-margin') || '—', 'profit margin') +
        bars('Profit by quantity', [1, 10, 50, 100, q > 100 ? q : 500].map(function (n) { return { l: n + ' units', v: pr !== null ? pr * n : null, cls: n === q ? 'gold' : '' }; }));
    },
    '/margin-to-markup-calculator/': function () {
      charts.classList.add('one');
      var m = val('margin');
      return curve('Markup needed for each margin', function (x) { return x >= 99 ? 9900 : x / (100 - x) * 100; }, 80, m, '%', '%');
    },
    '/acos-calculator/': function () {
      charts.classList.add('one');
      return gauge('ACoS vs break-even and target', [{ k: 'acos', l: 'Your ACoS', v: val('o-acos'), c: 'var(--ink)' }, { k: 'be', l: 'Break-even', v: val('o-be'), c: G }, { k: 'tgt', l: 'Target', v: val('o-tgt'), c: Y }], 50) +
        bars('Sales split', [{ l: 'Ad sales', v: val('adsales') }, { l: 'Organic sales', v: (val('total') !== null && val('adsales') !== null) ? Math.max(0, val('total') - val('adsales')) : null, cls: 'gold' }, { l: 'Ad spend', v: val('spend'), cls: 'red' }]);
    },
    '/amazon-vs-ebay-vs-etsy-fees/': function () {
      charts.classList.add('one');
      return bars('What you keep on each marketplace', [{ l: 'Amazon FBA', v: val('o-amz') }, { l: 'eBay', v: val('o-ebay'), cls: 'gold' }, { l: 'Etsy', v: val('o-etsy') }]);
    }
  };
  function feeView(label) {
    return function () {
      var cost = (val('cost') || 0) + (val('shipcost') || 0), fees = val('o-fees'), keep = val('o-profit');
      return donut('Where each order goes', [{ l: 'Your costs', v: cost, c: N }, { l: label + ' fees', v: fees || 0, c: Y }, { l: keep !== null && keep < 0 ? 'Loss' : 'You keep', v: keep !== null ? Math.abs(keep) : 0, c: keep !== null && keep < 0 ? R : G, t: keep !== null ? money(keep) : '—' }], txt('o-margin') || '—', 'profit margin') +
        bars(label + ' fees, line by line', feeRows());
    };
  }
  VIEWS['/etsy-fee-calculator/'] = feeView('Etsy');
  VIEWS['/ebay-fee-calculator/'] = feeView('eBay');
  VIEWS['/amazon-fba-calculator/'] = feeView('Amazon');
  var view = VIEWS[path];

  var pending = false;
  function render() {
    pending = false;
    kp.querySelectorAll('b[data-src]').forEach(function (b) { var t = txt(b.getAttribute('data-src')); b.textContent = t || '—'; b.classList.toggle('neg', /^[−-]/.test(t)); });
    if (view) { try { charts.innerHTML = view(); } catch (e) { charts.innerHTML = ''; } }
  }
  function schedule() { if (!pending) { pending = true; requestAnimationFrame(render); } }
  new MutationObserver(schedule).observe(slip, { subtree: true, childList: true, characterData: true });
  tool.addEventListener('input', schedule); tool.addEventListener('change', schedule);
  render();
})();
